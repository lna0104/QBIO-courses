# DO NOT modify or add any import statements
from typing import Optional
from a1_support import *

# Name:
# Student Number: 
# ----------------

# Write your classes and functions here

def main() -> None:
    """The main function"""
    pass

if __name__ == "__main__":
    main()
